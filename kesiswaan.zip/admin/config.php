<?php
error_reporting(~E_NOTICE);
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'dbpesantren');
?>